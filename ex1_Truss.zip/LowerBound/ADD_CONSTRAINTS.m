function [B,bin,Iin_global,Aieq,bieq,Aeq,beq,Sl,sign,artVar_idx] = ADD_CONSTRAINTS( b,Eb,B,b_,Nx,Nl,bin,Iin_idx,Aieq,bieq,Icand)

I0 = setdiff( Icand,Iin_idx ); 

Sl = zeros(size(I0));
count = zeros(size(I0));
% Sl2 = zeros(size(I0));
for ii = 1:length(I0)
    D_ = prod(B(Eb{I0(ii)},:));
    Sl(ii)  = -D_*b_+b(Nx+I0(ii));
%     Sl2(ii) = Sl(ii)/(D_*b_);
    count(ii) = sum(D_);
end

% tmp_ = find(abs(Sl)<1e-8);
% Sl_ = Sl;
% Sl(tmp_) = []; count(tmp_) = []; I0(tmp_) = [];

tmp_ = find(~abs(Sl));
Sl_ = Sl;
Sl(tmp_) = []; count(tmp_) = []; I0(tmp_) = [];


count = abs(count-mean(count));
[~,Sl_idx] = sort(abs(Sl),'descend');
% [~,Sl_idx] = sort(count,'descend');
% [~,Sl_idx] = sort(Sl2,'descend');

% if sum(Sl<0)
if ~isempty(I0)
    Iin_local = Sl_idx(1:Nl);
    Iin_global = I0( Iin_local );
    D = [];
    for ii = 1:Nl
        D = [D; prod(B(Eb{Iin_global(ii)},:))];
    end
    sign = ( -D*b_+b(Nx+Iin_global) < 0 )*1; sign(~sign) = -1; % basis) 1:[..-1..], -1:[..1..] 
    B = [B(1:end-1,:) zeros(size(B,1)-1,size(D,1)); D -eye(size(D,1)).*repmat(sign,1,size(D,1)); B(end,:) zeros(1,size(D,1))];
    bin = [bin(1:end-1); b(Iin_global+Nx); 1];

    Nb = length(bin);
    Nl = length(Iin_local);
    if ~isempty(Aieq)
        Aieq = [Aieq(:,1:end-1) zeros(size(Aieq,1),Nl) Aieq(:,end)]; 
    end
    for ii = 1:Nl
        for jj = 1:length(Eb{Iin_global(ii)})
            a = zeros(1,Nb );
            a(Nb-Nl-1+ii) = 1;
            a(Eb{Iin_global(ii)}(jj)) = -1;
            Aieq = [Aieq; a];
            bieq = [bieq; 0];
        end
        a = zeros(1,Nb );
        a(Eb{Iin_global(ii)}) = 1;
        a(Nb-Nl+ii-1) = -1;
        Aieq = [Aieq; a];
        bieq = [bieq; length(Eb{Iin_global(ii)})-1];
    end
    artVar_idx = Nb-Nl-1+(1:Nl)';

else
    Nb = length(bin);
    Iin_global = [];  
    artVar_idx = [];
    sign = [];
    Sl = Sl_;
end

Aeq = zeros(1,Nb);
Aeq(Nb) = 1;
beq = 1;
   
