function F = GetMemberForce( P,K,T,MN,kl,Fixdof )
%{
x: member force F of each member (minus: compression; plus: tension)
--
P: External Node (global coord.)
K: global stiffness matrix
T: transformation matrix (global->local) of each member - cell array
MN: node information of each memeber
kl: local stiffness matrix in local coord.
Fixdof: fixed dof

%}

Nmember = length(kl);
Nnode = length(P)/2;

P(Fixdof) = [];
K_ = K;
K_(:,Fixdof) = []; K_(Fixdof,:) = [];
u_ = K_\P; % global displacement
u = zeros(2*Nnode,1); u(setdiff(1:2*Nnode,Fixdof)) = u_;

% local displacement
delta = []; 
for ii = 1:Nmember
    d_ = [u([MN(ii,1)*2-1+(0:1) MN(ii,2)*2-1+(0:1)])];
    T_ = [T{ii} zeros(2);zeros(2) T{ii}];
    delta = [delta T_*d_];
end

% local nodal force
x = [];
for ii = 1:Nmember
    x = [x kl{ii}*delta(:,ii)];
end

F = -x(1,:)';