%{
2018-07-10
Summary of results
%}
close all; clear
%%
load KHDbound KHD_lower KHD_upper
KHD_lower = max(KHD_lower);
KHD_upper = min(KHD_upper);
load UpperBound/truss_UpperBound.mat OPTIM
OPTIM_upper = 1-OPTIM(8:end);
load LowerBound/truss_LowerBound.mat OPTIM
OPTIM_lower = OPTIM(8:end);
Nconst = 6 + (1:length(OPTIM_lower));

%% figure
LW = 1.2; Fsz = 16; Msz = 4;

plot( Nconst,OPTIM_lower,'-b','MarkerSize',Msz,'Linewidth',LW )
hold on
plot( [Nconst(1) Nconst(end)],KHD_lower*ones(1,2),'--r','MarkerSize',Msz,'Linewidth',LW )
plot( Nconst,OPTIM_upper,'-b','MarkerSize',Msz,'Linewidth',LW )
plot( [Nconst(1) Nconst(end)],KHD_upper*ones(1,2),'--r','MarkerSize',Msz,'Linewidth',LW )

grid on
legend({'LP bounds (Bi-component)' 'KHD bounds (Greedy search)'},'Fontsize',Fsz-2,'Location','SouthEast',...
    'FontName','times new roman')

ax = gca;
ax.XAxis.FontSize = Fsz-4;
ax.YAxis.FontSize = Fsz-4;
axis([Nconst(1) Nconst(end) 0.08 0.10])
xlabel( 'Number of constraints','Fontsize',Fsz,'FontName','times new roman' )
ylabel( 'Failure probability','Fontsize',Fsz,'FontName','times new roman' )
saveas(gcf,'figure/Truss_result.emf')
saveas(gcf,'figure/Truss_result.pdf')