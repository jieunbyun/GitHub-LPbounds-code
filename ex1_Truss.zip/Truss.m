%{
Compute uni- and bi-comp prob's
in truss example (D.-S. Kim et al. 2013):
%}

clear; close all;
%% Structure Info.
Nnode = 12; Nmember = 25;
Coor.X = [0 2;2 4;4 6;6 8;8 10;10 12;0 2;2 4;4 6;6 8;8 10;12 10; 2 2;4 4;6 6;8 8;10 10;...
    4 2;2 4;6 4;4 6;6 8;8 6;8 10;10 8];
Coor.Y = [0 1.6;1.6 2.2;2.2 2.6;2.6 2.2;2.2 1.6;1.6 0;...
    0 0;0 0;0 0;0 0;0 0;0 0;...
    1.6 0;2.2 0;2.6 0;2.2 0;1.6 0;...
    2.2 0;1.6 0;2.6 0;2.2 0;2.6 0;...
    2.2 0;2.2 0;1.6 0];
theta = atan((Coor.Y(:,2)-Coor.Y(:,1))./(Coor.X(:,2)-Coor.X(:,1))); % for global coordinate
MN = [1 2;2 3;3 4;4 5;5 6;6 7;1 8;8 9;9 10;10 11;11 12;7 12;2 8;3 9;4 10;5 11;6 12;...
    3 8;2 9;4 9;3 10;4 11;5 10;5 12;6 11]; % member - node

L = sqrt( (Coor.X(:,2)-Coor.X(:,1)).^2 + (Coor.Y(:,2)-Coor.Y(:,1)).^2 )*1e3; % mm
E = 2e2; % kN/mm^2
A = [15*ones(6,1);14*ones(6,1);12*ones(5,1);13*ones(8,1)]*1e-4*1e6; % mm^2

k_ = [1 0 -1 0;0 0 0 0;-1 0 1 0;0 0 0 0];
Fixdof = [1 2 14];

T = {}; % transformation matrix: global -> local
for ii = 1:Nmember
    theta_ = theta(ii);
    T{ii,1} = [cos(theta_) -sin(theta_); sin(theta_) cos(theta_)];
end

kl = {}; % local stiffness matrix in local coord.
for ii = 1:Nmember
    kl{ii,1} = E*A(ii)/L(ii)*k_;
end

kg = {}; % local stiffness matrix in global coord.
for ii = 1:Nmember
    T_ = T{ii};
    T_ = [T_ zeros(2);zeros(2) T_];
    kg{ii,1} = T_'*kl{ii}*T_;
end

%% Structural Analysis
FailedMember = [];
K = zeros(Nnode*2);
for ii = setdiff(1:Nmember,FailedMember)
    n1_ = MN(ii,1); n2_ = MN(ii,2);
    K([n1_*2-1+(0:1) n2_*2-1+(0:1)],[n1_*2-1+(0:1) n2_*2-1+(0:1)]) = ...
        K([n1_*2-1+(0:1) n2_*2-1+(0:1)],[n1_*2-1+(0:1) n2_*2-1+(0:1)])+kg{ii};
end

L1_ = zeros(Nnode*2,1); L1_(2*9) = -1;
L2_ = zeros(Nnode*2,1); L2_(2*10) = -1;
L3_ = zeros(Nnode*2,1); L3_(2*11) = -1;
F1 = GetMemberForce( L1_,K,T,MN,kl,Fixdof ); % member force due to L1
F2 = GetMemberForce( L2_,K,T,MN,kl,Fixdof ); % member force due to L2
F3 = GetMemberForce( L3_,K,T,MN,kl,Fixdof ); % member force due to L3

%% Reliability analysis
% Parameters
Sigma.E = .276; L1.E = 110; L2.E = 110; L3.E = 110;
Sigma.var = (Sigma.E*.1)^2; L1.var = (L1.E*.1)^2; L2.var = (L2.E*.1)^2; L3.var = (L3.E*.1)^2;
Pcov = .8 * sqrt( L1.var*L2.var ); Scov = .3*Sigma.var;

% Uni-Comp prob
for ii = 1:Nmember
    Mean(ii,1) = Sigma.E * A(ii) - abs( L1.E * F1(ii) + L2.E * F2(ii) +L3.E * F3(ii));
    Var(ii,1) = Sigma.var*A(ii)^2 + L1.var *(F1(ii))^2 + L2.var *(F2(ii))^2 + L3.var *(F3(ii))^2 + ...
        2*Pcov*(F1(ii)*F2(ii) + F1(ii)*F3(ii) + F3(ii)*F2(ii));
    P1(ii,1) = normcdf(0,Mean(ii),sqrt(Var(ii))); % Failure prob. of each member
end

% bi-Comp prob.
Eb = mat2cell( nchoosek(1:Nmember,2),ones(nchoosek(Nmember,2),1),2 );
Sigma_all = zeros( Nmember );
for ii = 1:length(Eb)
    m1_ = Eb{ii}(1); m2_ = Eb{ii}(2);    
    Cov(ii,1) = Scov*A(m1_)*A(m2_) + L1.var*F1(m1_)*F1(m2_) + L2.var*F2(m1_)*F2(m2_) + L3.var*F3(m1_)*F3(m2_) + ...
        Pcov*( F1(m1_)*F2(m2_) + F1(m2_)*F2(m1_) +F1(m1_)*F3(m2_) + F1(m2_)*F3(m1_) + ...
        F3(m1_)*F2(m2_) + F3(m2_)*F2(m1_) );
    Sigma_ = [Var(m1_) Cov(ii);Cov(ii) Var(m2_)];
    P2(ii,1) = mvncdf( [0 0],[Mean(m1_) Mean(m2_)],Sigma_ );
    
    Sigma_all(m1_,m2_) = Cov(ii); Sigma_all(m2_,m1_) = Cov(ii);
end
for ii = 1:Nmember
    Sigma_all(ii,ii) = Var(ii);
end

% Prob. by Normal dist.
Pnorm = 1-mvncdf( zeros(Nmember,1),-Mean,Sigma_all );

%%
Nx = Nmember;
b = [P1;P2;1];
Eb = mat2cell(nchoosek(1:Nx,2),ones(nchoosek(Nx,2),1),2);

btmp_ = find( P1<1e-17 );
btmp2_ = find( cellfun( @(x) ~isempty(intersect(x,btmp_)),Eb ) );
btmp2_ = setdiff( 1:length(Eb),btmp2_ );

b = [P1(setdiff(1:Nx,btmp_)); P2(btmp2_); 1];
Nx = Nx-length(btmp_);
Eb = mat2cell(nchoosek(1:Nx,2),ones(nchoosek(Nx,2),1),2);

save Truss Nx b Eb
save Truss_all
