%{
2018-6-21
Get KHD bound by greedy search
%}

clear; close all;
%%
load Truss

%%
KHD_lower = zeros(Nx,1);
Ordering = [];
for ii = 1:Nx % Examine each starting point
    Ordering_ = ii;
    KHD_ = b(ii);
    for jj = 1:(Nx-1)
               
        idx_ = setdiff(1:Nx,Ordering_); tmp_ = zeros( size(idx_) );
        for kk = 1:length(idx_)
            tmp2_ = find( cellfun( @(x) all(ismember(x,[Ordering_ idx_(kk)])) * ismember(idx_(kk),x),Eb ) );
            tmp_(kk) = max( 0,b(idx_(kk)) - sum(b(tmp2_+Nx)) );
        end
        [tmp2_,idx2_] = max(tmp_);
        KHD_ = KHD_+tmp2_;
        Ordering_ = [Ordering_ idx_(idx2_)];
    end
    Ordering = [Ordering Ordering_'];
    KHD_lower(ii) = KHD_;
end
disp( ['Lower bound by KHD bound (by greed search) is ' num2str(max(KHD_lower))] )

%% Upper bound
KHD_upper = zeros(Nx,1);
Ordering = [];
for ii = 1:Nx % Examine each starting point
    Ordering_ = ii;
    KHD_ = b(ii);
    for jj = 1:(Nx-1)
               
        idx_ = setdiff(1:Nx,Ordering_); tmp_ = zeros( size(idx_) );
        for kk = 1:length(idx_)
            tmp2_ = find( cellfun( @(x) all(ismember(x,[Ordering_ idx_(kk)])) * ismember(idx_(kk),x),Eb ) );
            tmp_(kk) = b(idx_(kk)) - max(b(tmp2_+Nx));
        end
        [tmp2_,idx2_] = min(tmp_);
        KHD_ = KHD_+tmp2_;
        Ordering_ = [Ordering_ idx_(idx2_)];
    end
    Ordering = [Ordering Ordering_'];
    KHD_upper(ii) = KHD_;
end
save KHDbound
disp( ['Upper bound by KHD bound (by greed search) is ' num2str(min(KHD_upper))] )
save KHDbound

