% %{
% 2018-06-25 Ji-Eun Byun
% %}
% 
clear; close all;

%% Problem: change into parallel
load Truss

b_ = b;
b(1:Nx) = 1-b_(1:Nx);
for ii = 1:length(Eb)
    x1_ = Eb{ii}(1); x2_ = Eb{ii}(2);
    EuE_ = b_(x1_)+b_(x2_)-b_(ii+Nx);
    b(ii+Nx) = 1-EuE_;
end

save Truss_complimentary b Nx Eb
% load Truss_complimentary
%% Initialization - generate subproblem's constraints (w/ constraints in 1st cutset: (13))
tmp_ = 1; % RANDOM CHOICE
bin = [b(1:Nx);b(Nx+tmp_);1];
Iin_idx = tmp_;

Nb = length(bin); Aieq = []; bieq = [];
for ii = 1:length(Eb{tmp_})
    a_ = zeros(1,Nb);
    a_(Eb{tmp_}(ii)) = -1;
    a_(Nx+1) = 1;
    Aieq = [Aieq; a_];
    bieq = [bieq; 0];
end
a_ = zeros(1,Nb);
a_(Eb{tmp_}) = 1;
a_(Nx+1) = -1;
Aieq = [Aieq; a_];
bieq = [bieq; 1];
Aeq = zeros(1,Nb); Aeq(Nb) = 1; beq = 1;

%% PHASE I
[b_, B, flag] = PHASE1( bin,Aieq,bieq,Aeq,beq );
save DelColSysRel_phase1
% % load DelColSysRel_phase1

%% PHASE II
[b_,B,cB,z] = PHASE2_MIN(bin,Aieq,bieq,Aeq,beq,B,@fc_parallel,Nx);
save DelColSysRel_phase2
% load DelColSysRel_phase2
% 
%% Add Constraints
OPTIM = z; maxSl = []; negSl = [];
Nl = 1; % # of constraints to be added at a time
Iin_global = 1;
tmp_ = 1:length(Eb);

Sl = -1;

load ex1
while ~isempty(Iin_global)
    [B,bin,Iin_global,Aieq,bieq,Aeq,beq,Sl,sign,artVar_idx] = ...
        ADD_CONSTRAINTS( b,Eb,B,b_,Nx,Nl,bin,Iin_idx,Aieq,bieq,tmp_);
    Iin_idx = [Iin_idx(:); Iin_global(:)];
    [b_,B,cB,z] = REOPT_MIN(bin,Aieq,bieq,Aeq,beq,B,@fc_parallel,Nx,sign,artVar_idx);
    OPTIM = [OPTIM; z]; 
    maxSl = [maxSl; max(abs(Sl))];
    negSl = [negSl; sum(Sl<0)];
    disp( [' # of negative constraints: ' num2str(sum(Sl<0))] )
    save ex1
    
    if rem(length(OPTIM),10)==1; save ex1_backup; end

end
save truss_UpperBound