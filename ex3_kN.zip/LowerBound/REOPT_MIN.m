function [b_,B,cB,z] = REOPT_MIN(bin,Aieq,bieq,Aeq,beq,B,fc,N,k,sign,artVar_idx)

M = 1e6;

Nb = length(bin);
cB = fc( B,N,k );
artVars = []; sign_ = [];
for ii = 1:length(artVar_idx)
    artVars_ = find((B(artVar_idx(ii),:)).*(~B(end,:)));
    artVars = [artVars; artVars_];
    cB(artVars_) = M;  
    sign_ = [sign_; sign(ii)];
end
b_ = lsqminnorm(B,bin);
btmp = ( abs(b_) <= 1e-14 );
b_(btmp) = 0;
z = cB*b_; 

Nsub = length(N);
% for zero cost
Aieq2 = Aieq; bieq2 = bieq;
for ii = 1:Nsub
    a_ = zeros(1,Nb);
    comp_ = sum(N(1:ii-1))+(1:N(ii));
    a_(comp_) = 1; % x1+...+xN <= N-k for all sub
    Aieq2 = [Aieq2; a_];
    bieq2 = [bieq2; N(ii)-k(ii)];
end

niter = 0;
while 1      
    niter = niter+1;
    niter2 = 0;
    y_ = lsqminnorm(B',cB');
    y_( abs(y_) < 1e-12 ) = 0;        

    [a_opt,c_opt] = cplexbilp( -y_,Aieq,bieq,Aeq,beq );
    c_opt = -c_opt;

        
    if c_opt > 1+1e-8
        ain = a_opt;
    elseif c_opt < 1e-8
        if max( y_( artVars ) ) > M +1e-8
            ain = zeros(1,Nb);
            [~,y_max_idx] = max(y_( artVars ));
            ain( artVars(y_max_idx) ) = -1*sign_(y_max_idx);
        else
            break; % Optimal soln has been found.
        end
    elseif ~fc( a_opt,N,k )
        ain = a_opt;
    else

        % for 0 cost
        [a_opt,c_opt] = cplexbilp( -y_,Aieq2,bieq2,Aeq,beq );
        c_opt = -c_opt;
        a_opt = a_opt(1:Nb);

        if fc( a_opt,N,k ); error('Something is wrong in 0 cost setting'); end % for debugging
        if c_opt < 0+1e-8 % c<=0
            break; % Optimal soln has been found.
        else
            ain = a_opt;
        end
    end

    if ~isempty( b_==0 ) 
        b_(b_==0) = 1e-14*rand(sum(b_==0),1);
    end

    A_ = lsqminnorm(B,ain);
    step = b_./A_;
    posidx_ = find(step>0);
    [~,Iout] = min( step(step>0) );
    Iout = posidx_( Iout );

    B_ = B; cB_ = cB;
    B(:,Iout) = ain;
    cB(Iout) = fc(ain,N,k);
    
    artVars = []; sign_ = [];
    for ii = 1:length(artVar_idx)
        artVars_ = find((B(artVar_idx(ii),:)).*(~B(end,:)));
        artVars = [artVars; artVars_];
        cB(artVars_) = M;  
        sign_ = [sign_; sign(ii)];
    end
    
    b_ = lsqminnorm(B,bin);
    btmp = ( abs(b_) <= 1e-14 );
    b_(btmp) = 0;     
    z = cB*b_;       
    
    if sum(b_<0)
        negb_ = min(b_(b_<0));
        negIdx = find(b_<0);
        perm_ = randperm( sum(b_<0) );
        negIdx = negIdx(perm_);
        for oo = 1:length(negIdx)
            B = B_;
            B(:,negIdx(oo)) = ain;
            b_ = lsqminnorm(B,bin);
            btmp = ( abs(b_) <= 1e-14 );
            b_(btmp) = 0;
            
            if ~sum(b_<0)
                cB = cB_;
                cB(negIdx(oo)) = fc(ain,N,k);
                z = cB*b_;
                break;
            else
                negb_ = [negb_ min(b_(b_<0))];
            end
        end
        
        if sum(b_<0)
            negb_ = negb_ + 10e-13 * rand( size(negb_) );
            [~,negbidx_] = max(negb_);
            B = B_; cB = cB_;
            if negbidx_ ==1
                B(:,Iout) = in;
                cB(Iout) = fc(ain,N,k);
            else
                B(:,negIdx(negbidx_-1)) = ain;
                cB(negIdx(negbidx_-1)) = fc(ain,N,k);
            end
            b_ = lsqminnorm(B,bin);
            b_(b_<0) = 0;
            btmp = ( abs(b_) <= 1e-14 );
            b_(btmp) = 0;
            z = cB*b_;
            
            save ex1_negSol
        end
    end
    
    if rem(niter,400) == 1
        disp( ['[Phase 2-MIN-Reopt] ' num2str(niter) '-th iter -- Cost function: ' num2str(z)] );
        save DelColSysRel_reopt_
    end
end

disp( ['[Phase 2-MIN-Reopt] Optimal value: ' num2str(z)] )
save DelColSysRel_reopt