function TorF = fc_kN( C,N,k )
%{
cost function for
a series system consisting of k out of N systems
Failure prob.
%}

C = round(C);
TorF = zeros( 1,size(C,2) );
for ii = 1:length(N)
    comp_ = sum( N(1:ii-1) ) + (1:N(ii));
    TorF = TorF + ( sum( C(  comp_,: ) ) > N(ii)-k(ii) );
end
TorF = (TorF>0)*1;
