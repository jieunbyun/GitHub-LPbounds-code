function [b_, B, flag] = PHASE1( bin,Aieq,bieq,Aeq,beq )

COST_PHASE1 = @(x) ( (sum(x) == 1) .* (~x(end,:)) );
Nb2 = length(bin);

B = eye(Nb2);
cB = COST_PHASE1(B);
b_ = lsqminnorm(B,bin);
btmp = ( abs(b_) <= 1e-14 );
b_(btmp) = 0;

z = 1; niter = 0;

while sum(cB)
    niter = niter+1;
    y_ = lsqminnorm(B',cB');
    y_( abs(y_) < 0.1/det(B) ) = 0;
    [a_opt,c_opt] = cplexbilp( -y_,Aieq,bieq,Aeq,beq );
    c_opt = -c_opt;
    
    if c_opt > 1e-12
        ain = a_opt;
    elseif max( y_ ) > 1+1e-12
        ain = zeros(Nb2,1);
        [~,y_max_idx] = max(y_);
        ain(y_max_idx) = 1;
    else
%         break;
        ain = a_opt;
    end
    
    if ~isempty( b_==0 ) 
        b_(b_==0) = 1e-14*rand(sum(b_==0),1);
    end
    
    A_ = lsqminnorm(B,ain);
    step = b_./A_;
    posidx_ = find(step>0);
    [~,Iout] = min( step(step>0) );
    Iout = posidx_( Iout );
    
    B(:,Iout) = ain;
    cB(Iout) = COST_PHASE1(ain);
    b_ = lsqminnorm(B,bin);
    btmp = ( abs(b_) <= 1e-14 );
    b_(btmp) = 0;
    z = cB*b_;   
    
    if rem(niter,200) == 1
        disp( ['[Phase 1] ' num2str(niter) '-th iter -- Cost function: ' num2str(z) ' | Remaining art. var.: ' num2str( sum(cB) ) ] );
        save DelColSysRel_phase1_
    end
end

if sum(cB)
    flag = -1; % Infeasible problem.
else
    flag = 1; % Initial soln has been found.
end

disp( ['[Phase 1] # of remaining artificial variables: ' num2str(sum(cB)) ' (If greater than zero and cost>0, the given problem is infeasible.)'] );