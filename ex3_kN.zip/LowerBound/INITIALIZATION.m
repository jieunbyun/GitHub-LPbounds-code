function [b,Eb,bin,Iin_idx,Aieq,bieq,Aeq,beq] = INITIALIZATION(Nx,b,Eb,Ng2,Ng3,Ni)

I2_ = 1:nchoosek(Nx,2);
Sg2 = zeros(length(I2_),1);
for ii = 1:length(I2_)
    Sg2(ii) = max( b(Eb{I2_(ii)}) ) - b( Nx+I2_(ii) );
end
Sg2 = Sg2 + rand( size(Sg2) )*min(Sg2)*1e-4;
[~,Sg2_idx] = sort(Sg2,'descend');
Sg2_idx = Sg2_idx(1:Ng2);
Eb2 = Eb(Sg2_idx);
P2 = b( Nx+Sg2_idx );

Eb_ = Eb(I2_);
I3_ = nchoosek(Nx,2) + (1:nchoosek(Nx,3));
Sg3 = zeros(length(I3_),1);
for ii = 1:length(I3_)
    tmp_ = Eb{nchoosek(Nx,2)+ii};
    tmp2_ = find( cellfun( @(x) all(ismember( x,tmp_ )),Eb_ ) );
    Sg3(ii) = min( b( nchoosek(Nx,2)+tmp2_ ) ) - b( nchoosek(Nx,2)+ii );    
end
Sg3 = Sg3 + rand( size(Sg3) )*min(Sg3)*1e-4;
[~,Sg3_idx] = sort(Sg3,'descend');
Sg3_idx = Sg3_idx(1:Ng3);
Eb3 = Eb( nchoosek(Nx,2)+Sg3_idx );
P3 = b( Nx+nchoosek(Nx,2)+Sg3_idx );

Iin_idx = 1:Ni;
b = [b(1:Nx); P2; P3; 1];
Eb = [Eb2; Eb3];

Nc = length(Iin_idx)+1+Nx;
Aieq = []; bieq = [];
for ii = 1:length(Iin_idx)
    Ii_ = Iin_idx(ii);
    for jj = 1:length(Eb{Ii_})
        a = zeros(1,Nc); % ai<=aj
        a(Nx+ii) = 1;
        a(Eb{Ii_}(jj)) = -1;
        Aieq = [Aieq; a];
        bieq = [bieq; 0];
    end
    a = zeros(1,Nc); % sum(1-aj)+ai >=1
    a(Eb{Ii_}) = 1;
    a(Nx+ii) = -1;
    Aieq = [Aieq; a];
    bieq = [bieq; length(Eb{Ii_})-1];
end
Aeq = zeros(1,Nc);
Aeq(end) = 1;
beq = 1;
Iin_idx = 1:Ni;

bin = [b(1:Nx); b(Nx+Iin_idx); 1];