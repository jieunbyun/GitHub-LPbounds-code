function [b_,B,cB,z] = PHASE2_MIN(bin,Aieq,bieq,Aeq,beq,B,fc,N,k)
Nb = length(bin);
cB = fc( B,N,k );
b_ = lsqminnorm(B,bin);
btmp = ( abs(b_) <= 1e-14 );
b_(btmp) = 0;
z = cB*b_; 

Nsub = length(N);

% for zero cost
Aieq2 = Aieq; bieq2 = bieq;
for ii = 1:Nsub
    a_ = zeros(1,Nb);
    comp_ = sum(N(1:ii-1))+(1:N(ii));
    a_(comp_) = 1; % x1+...+xN <= N-k for all sub
    Aieq2 = [Aieq2; a_];
    bieq2 = [bieq2; N(ii)-k(ii)];
end

niter = 0;
while 1    
    niter = niter+1;
    niter2 = 0;
    y_ = lsqminnorm(B',cB');
    y_( abs(y_) < 1e-12 ) = 0;

    [a_opt,c_opt] = cplexbilp( -y_,Aieq,bieq,Aeq,beq );
    c_opt = -c_opt;

    if c_opt > 1+1e-12
        ain = a_opt;
    elseif c_opt < 1e-12 || isempty( c_opt )
        break; % Optimal soln has been found.
    elseif ~fc( a_opt,N,k )
        ain = a_opt;
    else
        
        [a_opt,c_opt] = cplexbilp( -y_,Aieq2,bieq2,Aeq,beq );
        c_opt = -c_opt;
        
        if fc( a_opt,N,k ); error('Something is wrong in 0 cost setting'); end % for debugging
        if c_opt < 0+1e-12 % c<=0
            break; % Optimal soln has been found.
        else
            ain = a_opt;
        end
    end       

    if ~isempty( b_==0 ) 
        b_(b_==0) = 1e-14*rand(sum(b_==0),1);
    end

    A_ = lsqminnorm(B,ain);
    step = b_./A_;
    posidx_ = find(step>0);
    [~,Iout] = min( step(step>0) );
    Iout = posidx_( Iout );

    B(:,Iout) = ain;
    cB(Iout) = fc(ain,N,k);
    b_ = lsqminnorm(B,bin);
    btmp = ( abs(b_) <= 1e-14 );
    b_(btmp) = 0;
    z = cB*b_;     
    
    if rem(niter,400) == 1
        disp( ['[Phase 2-MIN] ' num2str(niter) '-th iter -- Cost function: ' num2str(z)] );
        save DelColSysRel_phase2_
    end
end

disp( ['[Phase 2-MIN] Optimal value: ' num2str(z)] )
save DelColSysRel_phase2