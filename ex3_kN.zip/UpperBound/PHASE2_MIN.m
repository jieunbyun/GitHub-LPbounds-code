function [b_,B,cB,z] = PHASE2_MIN(bin,Aieq,bieq,Aeq,beq,B,fc,N,k)
Nb = length(bin);
cB = fc( B,N,k );
b_ = lsqminnorm(B,bin);
btmp = ( abs(b_) <= 1e-14 );
b_(btmp) = 0;
z = cB*b_; 

Nsub = length(N);

niter = 0;
while 1    
    niter = niter+1;

    y_ = lsqminnorm(B',cB');
    
    Aieq3 = Aieq; bieq3 = bieq;
    for ii = 1:size(B,2)
        a_ = zeros(1,Nb);
        a_( logical(B(:,ii)) ) = 1;
        a_( ~B(:,ii) ) = -1;
        Aieq3 = [Aieq3; a_]; bieq3 = [bieq3; sum(B(:,ii))-1];
    end
    
    [a_opt,c_opt] = cplexbilp( -y_,Aieq3,bieq3,Aeq,beq );
    c_opt = -c_opt;

    if c_opt > 1+1e-8
        ain = a_opt;
    elseif c_opt < 1e-8 || isempty( c_opt )
        break; % Optimal soln has been found.
    elseif ~fc( a_opt,N,k )
        ain = a_opt;
    else
        ain = [];
        for ii = 1:Nsub
            Aieq2 = Aieq3; bieq2 = bieq3;
            a_ = zeros(1,Nb);
            comp_ = sum(N(1:ii-1))+(1:N(ii));
            a_(comp_) = 1; % x1+...+xN <= k-1 for sub i
            Aieq2 = [Aieq2; a_]; bieq2 = [bieq2; k(ii)-1];
        
            [a_opt,c_opt] = cplexbilp( -y_,Aieq2,bieq2,Aeq,beq );
            c_opt = -c_opt;

            if fc( a_opt,N,k ); error('Something is wrong in 0 cost setting'); end % for debugging
            if c_opt > 1e-8 % c>0
                ain = a_opt; % next basis has been found.
                break;
            end
        end
        if isempty(ain)
            break;
        end % Optimal has been found.
        
    end       

    if sum( b_==0 ) 
        b_(b_==0) = min(b_(b_>0))*1e-5*rand(sum(b_==0),1);
    end

    A_ = lsqminnorm(B,ain);
    step = b_./A_;
    posidx_ = find(step>0);
    [~,Iout] = min( step(step>0) );
    Iout = posidx_( Iout );

    B_ = B;
    B(:,Iout) = ain;
    cB(Iout) = fc(ain,N,k);
    b_ = lsqminnorm(B,bin);
    btmp = ( abs(b_) <= 5e-14 );
    b_(btmp) = 0;
    if sum(b_<0)
        error('Negative solution has occurred!');
    end
    z = cB*b_;     
    
    if rem(niter,400) == 1
        disp( ['[Phase 2-MIN] ' num2str(niter) '-th iter -- Cost function: ' num2str(z)] );
        save DelColSysRel_phase2_
    end
end

disp( ['[Phase 2-MIN] Optimal value: ' num2str(z)] )
save DelColSysRel_phase2