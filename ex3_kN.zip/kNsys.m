%{
08-13-18 TUE
LP bound
Ex3: SINGLE k out of N system 
%}
clear; close all;
%%
Nx = 20;
k = 18;

N = Nx;
Pf = 1e-4;
Pf2 = 5e-5;

P1 = Pf*ones(Nx,1);
P2 = Pf2*ones(nchoosek(Nx,2),1);
b = [P1; P2; 1];

Eb = nchoosek(1:Nx,2);
Eb = mat2cell(Eb,ones(size(Eb,1),1),2);

save kNsys Nx b Eb N k

%% Soln. by correlated binomial model
rho = (Pf2-Pf^2)/Pf/(1-Pf);
Pfsys_bino = 0;
for kk = 0:(N-k)
    Pfsys_bino = Pfsys_bino+nchoosek(N,kk)*Pf^kk*(1-Pf)^(N-kk)*(1-rho);
    if kk == 0
        Pfsys_bino = Pfsys_bino+(1-Pf)*rho;
    end
end
Pfsys_bino = 1-Pfsys_bino;
