function nCk = mynchoosek( n,k )

    nCk = sum( log(1:n) ) - sum( log(1:k) ) - sum( log(1:(n-k)) );
    nCk = exp(nCk);
    nCk = round(nCk);
end