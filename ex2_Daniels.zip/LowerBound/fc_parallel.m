function TorF = fc_parallel( C,Nx )
%{
cost function for parallel system

all 1->1
%}

C = round(C);
TorF = prod( C(1:Nx,:) );


