%{
2018-05-10 Ji-Eun Byun
Daniel's system (Parallel system) w/ bi-component level probs
Refer: LP bound paper: Song & ADK (2003)

Conclusion: I think Daniels system is not good for large system;;
%}
clear; close all;
%% Problem: Formulation as a series system of complementray component events
for Nx = 21:30 % # of wires
L = 35; % load: 5-8 is examined in the 2003 paper
Fx = @(x) (1-exp(-0.01*(x.^5)));

% Component
Fs = [];
for ii = 1:Nx
    Fs = [Fs; Fx(L/(Nx-ii+1))];
end

% Unicomponent 
P1 = [];
for ii = 1:Nx
    Pi_ = Fs(ii);
    Fi_ = 0;
    for rr = ii:Nx
        Fi_ = Fi_+mynchoosek(Nx,rr) * Pi_^rr * (1-Pi_)^(Nx-rr);        
    end
    P1 = [P1; Fi_];
end

% Bicomponent
P2 = [];
combs = nchoosek( 1:Nx,2 );
for kk = 1:size(combs,1)
    ii=combs(kk,1); jj = combs(kk,2);
    Fx_ = Fs(ii); Fy_ = Fs(jj);
    P2_ = 0;
    for rr = ii:Nx
        for ss = max(0,jj-rr):(Nx-rr)
            P2_ = P2_+factorial(Nx)/factorial(rr)/factorial(ss)/factorial(Nx-rr-ss) * ...
                Fx_^rr * (Fy_-Fx_)^ss * (1-Fy_)^(Nx-rr-ss);
        end
    end
    P2 = [P2; P2_];
end

b = [P1; P2; 1]; % RHS of original problem
nConst = length(b);
Eb = mat2cell( combs,ones(size(combs,1),1),size(combs,2) );
eval( ['save Daniels' num2str(Nx) ' Nx b Eb'])

end

%% Analytic Solution (Daniels 1945)
Nx = 21:30; exact = zeros( size(Nx) );
kk = 0;
for nn = Nx
    kk = kk+1;
    tmp_ = zeros(nn);
    for ii = 1:nn
        jj_ = nn+1-ii;
        bj_ = Fx(L/jj_);
        if ii>1
            tmp_(ii,ii-1) = 1;
        end
        tmp_(ii,ii:nn) = bj_.^(1:jj_) ./factorial(1:jj_);
    end
    exact(kk) = factorial(nn)*det(tmp_);
end

save EXACT exact