%{
18-07-10
Summary
%}
close all; clear
%% KHD bound
load KHD_all

%% LP bound
LP_BOUND = zeros( size(KHD_BOUND) );
ii = 0;
for nn = Nx
    ii = ii+1;
    eval( ['load LowerBound/Daniels' num2str(nn) '_Lowerbound.mat z'] )
    LP_BOUND(ii,1) = z;
end

ii = 0;
for nn = Nx
    ii = ii+1;
    eval( ['load UpperBound/Daniels' num2str(nn) '_Upperbound.mat z'] )
    LP_BOUND(ii,2) = 1-z;
end

save Results KHD_BOUND LP_BOUND Nx
load EXACT

%% figure
LW = 1.52; LW2 = 1; Fsz = 16; Msz = 9; Msz2 = 3;

semilogy( Nx,exact,'-k','Linewidth',LW )
hold on
semilogy( Nx,LP_BOUND(:,1),'-b*','Linewidth',LW,'markers',Msz )
semilogy( Nx,KHD_BOUND(:,1),'--ro','Linewidth',LW2,'markers',Msz2,'MarkerFaceColor','r' )

semilogy( Nx,LP_BOUND(:,2),'-b*','Linewidth',LW,'markers',Msz )
semilogy( Nx,KHD_BOUND(:,2),'--ro','Linewidth',LW2,'markers',Msz2,'MarkerFaceColor','r' )



grid on
legend({'Daniels (Exact)' 'LP bounds (Bi-component)' 'KHD bounds (Greedy search)'},'Fontsize',Fsz-2,'Location','SouthWest',...
    'FontName','times new roman')

ax = gca;
ax.XAxis.FontSize = Fsz-4;
ax.YAxis.FontSize = Fsz-4;
axis([Nx(1) Nx(end) 1e-4 1e0])
xlabel( 'Number of wires','Fontsize',Fsz,'FontName','times new roman' )
ylabel( 'Failure probability','Fontsize',Fsz,'FontName','times new roman' )
saveas(gcf,'figure/Daniels_result.emf')
saveas(gcf,'figure/Daniels_result.pdf')

