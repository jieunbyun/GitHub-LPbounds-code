%{
2018-6-21
Get KHD bound by greedy search
%}

clear; close all;
%%
for Nx = 21:30
% for Nx = 30
% Nx = 6;

    eval( ['load Daniel' num2str(Nx)])
    
    b = round(b,8,'significant');
    b_ = b;
    for ii = 1:Nx
        b(ii) = 1-b_(ii);
    end
    for ii = 1:length(Eb)
        b(ii+Nx) = 1-( sum(b_(Eb{ii}))-b_(ii+Nx) );
    end
%     save Daniel_complimentary b Eb Nx

    %% 
    KHD_lower = zeros(Nx,1);
    Ordering = [];
    for ii = 1:Nx % Examine each starting point
        Ordering_ = ii;
        KHD_ = b(ii);
        for jj = 1:(Nx-1)

            idx_ = setdiff(1:Nx,Ordering_); tmp_ = zeros( size(idx_) );
            for kk = 1:length(idx_)
                tmp2_ = find( cellfun( @(x) all(ismember(x,[Ordering_ idx_(kk)])) * ismember(idx_(kk),x),Eb ) );
                tmp_(kk) = max( 0,b(idx_(kk)) - sum(b(tmp2_+Nx)) );
            end
            [tmp2_,idx2_] = max(tmp_);
            KHD_ = KHD_+tmp2_;
            Ordering_ = [Ordering_ idx_(idx2_)];
        end
        Ordering = [Ordering Ordering_'];
        KHD_Upper(ii) = 1-KHD_;
    end
    disp( ['Upper bound by KHD bound (by greed search) is ' num2str(min(KHD_Upper))] )

    %% Lower bound
    KHD_upper = zeros(Nx,1);
    Ordering = [];
    for ii = 1:Nx % Examine each starting point
        Ordering_ = ii;
        KHD_ = b(ii);
        for jj = 1:(Nx-1)

            idx_ = setdiff(1:Nx,Ordering_); tmp_ = zeros( size(idx_) );
            for kk = 1:length(idx_)
                tmp2_ = find( cellfun( @(x) all(ismember(x,[Ordering_ idx_(kk)])) * ismember(idx_(kk),x),Eb ) );
                tmp_(kk) = b(idx_(kk)) - max(b(tmp2_+Nx));
            end
            [tmp2_,idx2_] = min(tmp_);
            KHD_ = KHD_+tmp2_;
            Ordering_ = [Ordering_ idx_(idx2_)];
        end
        Ordering = [Ordering Ordering_'];
        KHD_Lower(ii) = 1-KHD_;
    end
    save KHDbound
    disp( ['Lower bound by KHD bound (by greed search) is ' num2str(max(KHD_Lower))] )
    eval(['save KHDbound' num2str(Nx)])
end

KHD_BOUND = [];
for Nx = 21:30
    eval(['load KHDbound' num2str(Nx)])
    KHD_BOUND = [KHD_BOUND; max(0,max(KHD_Lower)) min(KHD_Upper)];
end
Nx = 21:30;
save KHD_all KHD_BOUND Nx

semilogy( 21:30,KHD_BOUND(:,1),'s--' )
hold on
semilogy( 21:30,KHD_BOUND(:,2),'s--' )

%% Exact Solution

