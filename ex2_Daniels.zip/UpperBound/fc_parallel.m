function TorF = fc_parallel( C,Nx )
%{
cost function for parallel system
%}

C = round(C);
TorF = sum( C(1:Nx,:) );
TorF = (TorF>0)*1;
