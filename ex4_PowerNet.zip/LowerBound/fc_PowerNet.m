function TorF = fc_PowerNet( C,Cut )

C = round(C);
C = 1-C;
TorF = zeros( 1,size(C,2) );

% Super Comps
Scomps{1}=[1:3 10:12];
Scomps{2,1} = 4:6;
Scomps{3} = [7:9 13:15];
Scomps{4} = [16:18 25:27];
Scomps{5} = 19:21;
Scomps{6} = [22:24 28:30];
Scomps{7} = [31:33 37:39];
Scomps{8} = [34:36 43:45];
Scomps{9} = 40:42;
Scomps{10} = 46:48;
Scomps{11} = [49:51 55:57];
Scomps{12} = 52:54;
Scomps{13} = 58:59;


for jj = 1:size(C,2)
    Scomps_state = zeros(length(Scomps),1);
    for ii = 1:length(Scomps)
        Scomps_state(ii) = prod( C(Scomps{ii},jj) );
    end
    
    Scomps_fail = find(1-Scomps_state);
    tmp = cellfun( @(x) all( ismember(x,Scomps_fail) ),Cut );
    if sum(tmp)
        TorF(jj) = 1;
    end
end