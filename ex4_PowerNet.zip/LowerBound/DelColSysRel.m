%{
2018-06-20 Ji-Eun Byun

%}

clear; close all;

%% Problem
% %{
load PowerNet
b = round(b,8,'significant');

%% Initialization - generate subproblem's constraints (w/ constraints in 1st cutset: (13))
tmp_ = 1; % RANDOM CHOICE
bin = [b(1:Nx);b(Nx+tmp_);1];
Iin_idx = tmp_;

Nb = length(bin); Aieq = []; bieq = [];
for ii = 1:length(Eb{tmp_})
    a_ = zeros(1,Nb);
    a_(Eb{tmp_}(ii)) = -1;
    a_(Nx+1) = 1;
    Aieq = [Aieq; a_];
    bieq = [bieq; 0];
end
a_ = zeros(1,Nb);
a_(Eb{tmp_}) = 1;
a_(Nx+1) = -1;
Aieq = [Aieq; a_];
bieq = [bieq; 1];
Aeq = zeros(1,Nb); Aeq(Nb) = 1; beq = 1;

%% PHASE I
[b_, B, flag] = PHASE1( bin,Aieq,bieq,Aeq,beq );
save DelColSysRel_phase1
% load DelColSysRel_phase1

%% PHASE II
[b_,B,cB,z] = PHASE2_MIN(bin,Aieq,bieq,Aeq,beq,B,@fc_PowerNet,Cut);
save DelColSysRel_phase2
% %}
load DelColSysRel_phase2
load PowerNet
% 
%% Add Constraints
OPTIM = z; maxCount = [];
maxSl = [];
Nl = 1; % # of constraints to be added at a time
Iin_global = 1;

Sl = -1;
% load ex1_backup
%}

% load ex1
% 
comp_in_ = cell2mat( Scomps([13 10 12 8 9 11])' );
tmp_ = find( cellfun( @(x) all(ismember(x,comp_in_)),Eb ) );

while ~isempty(Iin_global)
    [B,bin,Iin_global,Aieq,bieq,Aeq,beq,Sl,sign,artVar_idx,count] = ...
        ADD_CONSTRAINTS( b,Eb,B,b_,Nx,Nl,bin,Iin_idx,Aieq,bieq,tmp_,cB );
    Iin_idx = [Iin_idx(:); Iin_global(:)];
    [b_,B,cB,z] = REOPT_MIN(bin,Aieq,bieq,Aeq,beq,B,@fc_PowerNet,Nx,sign,artVar_idx,Cut);
    OPTIM = [OPTIM; z]; 
    maxCount = [maxCount; max(abs(count))];
    maxSl = [maxSl; max(abs(Sl))];
    disp( [' max count: ' num2str(max(abs(count)))] )
    disp( [' Added constraint: ' num2str( Eb{Iin_global} ) ] )
    save ex1
    
    if rem(length(OPTIM),10)==1; save ex1_backup; end
end

save PowerNet_LowerBound
