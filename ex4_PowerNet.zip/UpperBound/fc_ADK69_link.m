function TorF = fc_ADK69_link( C,Cut )
%{
Determine if the system fails (0) or success (1)
in Der Kieurighian and Song (2008) example
(Numbering of comps and super-comps is different!!)

Input: 
C: the state of 59 comps (vector or matrix w/ each column being several cases)

Output:
TorF: 1 if system succeeds, 0 otherwise

e.g.,
C=round(rand(59,1));
TorF = ADK69_Esys( C );
%}

% Super Comps
Scomps{1}=[1:3 10:12];
Scomps{2,1} = 4:6;
Scomps{3} = [7:9 13:15];
Scomps{4} = [16:18 25:27];
Scomps{5} = 19:21;
Scomps{6} = [22:24 28:30];
Scomps{7} = [31:33 37:39];
Scomps{8} = [34:36 43:45];
Scomps{9} = 40:42;
Scomps{10} = 46:48;
Scomps{11} = [49:51 55:57];
Scomps{12} = 52:54;
Scomps{13} = 58:59;

% Link-sets (in terms of Scomps)
Link{1} = [6 12 13]; Link{2} = [8 10 13]; Link{3} = [2 9 10 13]; Link{4} = [4 5 12 13]; Link{5} = [3 5 12 13];
Link{6} = [6 10 11 13]; Link{7} = [8 11:13]; Link{8} = [1 3 9 10 13]; Link{9} = [1 2 5 12 13]; Link{10} = [1 4 9 10 13];
Link{11} = [1 5 7 12 13]; Link{12} = [3 5 10 11 13]; Link{13} = [2 9 11 12 13]; Link{14} = [4 5 10:13]; Link{15} = [7 9 10 13];
Link{16} = [7 9 11:13]; Link{17} = [1 2 5 10 11 13]; Link{18} = [1 3 9 11:13]; Link{19} = [1 5 7 10 11 13]; 
Link{20} = [1 5 8 9 12 13]; Link{21} = [1 4 9 11:13]; Link{22} = [1 5 6 9 10 13];

C = round(C);
TorF = zeros( 1,size(C,2) );
for jj = 1:size(C,2)

    Scomps_state = zeros(length(Scomps),1);
    for ii = 1:length(Scomps)
        Scomps_state(ii) = prod( C(Scomps{ii},jj) );
    end
    
    Scomps_fail = find(1-Scomps_state);
    tmp = cellfun( @(x) all( ismember(x,Scomps_fail) ),Cut );
    if sum(tmp)
        TorF(jj) = 1;
    end
end     
TorF = 1-TorF;