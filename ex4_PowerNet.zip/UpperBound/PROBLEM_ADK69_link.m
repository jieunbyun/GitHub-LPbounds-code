%{
ADK69 example
%}
function [Nx b Eb Scomps Cut Link] = PROBLEM_ADK69_link

Nx = 59; % # of r.v.'s
sub{1} = 1:15; sub{2} = 16:30; sub{3} = 31:45; sub{4} = 46:59; % substation (re-numbering of comp's)
type{1} = [2 5 8 11 14 17 20 23 26 29 32 35 38 41 44 47 50 53 56]; % circuit
type{2} = [1 3 4 6 7 9 10 12 13 15 18 20 21 23 24 26 27 29 30 32 31 33 34 36 37 39 40 42 43 45 46 48 49 51 52 54 55 57 58]; % switch
type{3} = 59; % transformer

% Ui's
log_mean.R = [0.6 0.75 1.3]; % unit:g
log_cov.R = [0.2 0.2 0.5];
norm_var.R = log( 1+log_cov.R.^2 );
norm_mean.R = log( log_mean.R ) - .5*norm_var.R;

log_mean.A = .15; log_cov.A = .5;
norm_var.A = log( 1+log_cov.A.^2 );
norm_mean.A = log( log_mean.A ) - .5*norm_var.A;

log_mean.Q = 1; log_cov.Q = .2;
norm_var.Q = log( 1+log_cov.Q.^2 );
norm_mean.Q = log( log_mean.Q ) - .5*norm_var.Q;

log_mean.S = 1; log_cov.S = .4;
norm_var.S = log( 1+log_cov.S.^2 );
norm_mean.S = log( log_mean.S ) - .5*norm_var.S;

norm_mean.V = zeros(Nx,1);
for ii = 1:3
    norm_mean.V(type{ii}) = norm_mean.V(type{ii})+norm_mean.R(ii);
end
norm_mean.V = norm_mean.V-norm_mean.A;
norm_mean.V = norm_mean.V-norm_mean.Q;
norm_mean.V = norm_mean.V-norm_mean.S;

norm_var.V = ones( Nx )*norm_var.A;
norm_var.V( sub2ind( [Nx,Nx],1:Nx,1:Nx ) ) = norm_var.V( sub2ind( [Nx,Nx],1:Nx,1:Nx ) )+ ...
    norm_var.Q + norm_var.S;
for ii = 1:3
    norm_var.V( sub2ind( [Nx,Nx],type{ii},type{ii} ) ) = norm_var.V( sub2ind( [Nx,Nx],type{ii},type{ii} ) ) + ...
        norm_var.R(ii);
end
log_rho.R = [0.2 0.2 0.5];
for ii = 1:2 % Cov. by R ( there's only 1 Comp in type3 )    
    comb_ = nchoosek( type{ii},2 );
    rho_ = log_rho.R(ii);
    std_ = log_mean.R(ii) * log_cov.R(ii);
    mean_ = log_mean.R(ii);
    cov_ = log( rho_*std_^2 / mean_^2 + 1 );
    for jj = 1:size(comb_,1)
        norm_var.V( comb_(jj,1),comb_(jj,2) ) = norm_var.V( comb_(jj,1),comb_(jj,2) ) + cov_;
        norm_var.V( comb_(jj,2),comb_(jj,1) ) = norm_var.V( comb_(jj,2),comb_(jj,1) ) + cov_;
    end
end
for ii = 1:4 % Cov. by S
    comb_ = nchoosek( sub{ii},2 );
    for jj = 1:size(comb_,1)
        norm_var.V( comb_(jj,1),comb_(jj,2) ) = norm_var.V( comb_(jj,1),comb_(jj,2) ) + norm_var.S;
        norm_var.V( comb_(jj,2),comb_(jj,1) ) = norm_var.V( comb_(jj,2),comb_(jj,1) ) + norm_var.S;
    end
end

% Uni-comp prob.
P1 = [];
for ii = 1:Nx
    P1 = [P1; normcdf( 0,norm_mean.V(ii),sqrt(norm_var.V(ii,ii)) )];
end

% Bi-comp prob.
P2 = [];
for ii = 1:Nx
    for jj = ii+1:Nx
        P2 = [P2; mvncdf( [0 0]',norm_mean.V([ii jj]),norm_var.V( [ii jj],[ii jj] ) )];
    end
end

Eb = nchoosek( 1:Nx,2 );
Eb = mat2cell(Eb,ones(1,size(Eb,1)),2);


%%
% Super Comps
Scomps{1}=[1:3 10:12]; Scomps{2,1} = 4:6; Scomps{3} = [7:9 13:15]; Scomps{4} = [16:18 25:27];
Scomps{5} = 19:21; Scomps{6} = [22:24 28:30]; Scomps{7} = [31:33 37:39]; Scomps{8} = [34:36 43:45];
Scomps{9} = 40:42; Scomps{10} = 46:48; Scomps{11} = [49:51 55:57]; Scomps{12} = 52:54;
Scomps{13} = 58:59;

% Cut-sets (in terms of Scomps)
Cut{1} = 13; Cut{2} = [10 12]; Cut{3} = [8 9 11 12]; Cut{4} = [5 6 8 9];
Cut{5} = [5 6 10 11]; Cut{6} = [1 3 4 6 10 11]; Cut{7} = [1 3 4 6 8 9];
Cut{8} = [2 3 4 6 7 8]; Cut{9} = [1 2 5:8]; Cut{10} = [1 2 7 8 11 12];
Cut{11} = [2:5 7 8 11 12]; Cut{12} = [2:4 6 7 9:11];

% Link-sets (in terms of Scomps)
Link{1} = [6 12 13]; Link{2} = [8 10 13]; Link{3} = [2 9 10 13]; Link{4} = [4 5 12 13]; Link{5} = [3 5 12 13];
Link{6} = [6 10 11 13]; Link{7} = [8 11:13]; Link{8} = [1 3 9 10 13]; Link{9} = [1 2 5 12 13]; Link{10} = [1 4 9 10 13];
Link{11} = [1 5 7 12 13]; Link{12} = [3 5 10 11 13]; Link{13} = [2 9 11 12 13]; Link{14} = [4 5 10:13]; Link{15} = [7 9 10 13];
Link{16} = [7 9 11:13]; Link{17} = [1 2 5 10 11 13]; Link{18} = [1 3 9 11:13]; Link{19} = [1 5 7 10 11 13]; 
Link{20} = [1 5 8 9 12 13]; Link{21} = [1 4 9 11:13]; Link{22} = [1 5 6 9 10 13];

% Change the prob. to survival one
P2_ = P2;
P2 = zeros(size(Eb));
for ii = 1:nchoosek(Nx,2)
    comb_ = Eb{ii};
    P2(ii) = 1-(sum(P1(comb_))-P2_(ii));
end
P1 = 1-P1;
b = [P1; P2; 1];