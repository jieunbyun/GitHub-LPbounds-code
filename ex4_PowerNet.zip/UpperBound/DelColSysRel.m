%{
2018-06-18 Ji-Eun Byun

Based on the summarized algorithm in file1-9~
Constraint selection: the most different elements regardless of the sign
%}

clear; close all;

%% Problem
% %{
[Nx b Eb Scomps Cut Link] = PROBLEM_ADK69_link;
save PROBLEM_ADK69_link
% load PROBLEM_ADK69_link
% 
%% Initialization - generate subproblem's constraints (w/ constraints in 1st cutset: (13))
tmp_ = find( cellfun(@(x) ismember(Scomps{Cut{1}},x,'rows'),Eb(1:nchoosek(Nx,2)) ) );
bin = [b(1:Nx);b(Nx+tmp_);1];
Iin_idx = tmp_;

Nb = length(bin); Aieq = []; bieq = [];
for ii = 1:length(Scomps{Cut{1}})
    a_ = zeros(1,Nb);
    a_(Scomps{Cut{1}}(ii)) = -1;
    a_(Nx+1) = 1;
    Aieq = [Aieq; a_];
    bieq = [bieq; 0];
end
a_ = zeros(1,Nb);
a_(Scomps{Cut{1}}) = 1;
a_(Nx+1) = -1;
Aieq = [Aieq; a_];
bieq = [bieq; 1];
Aeq = zeros(1,Nb); Aeq(Nb) = 1; beq = 1;


%% PHASE I
[b_, B, flag] = PHASE1( bin,Aieq,bieq,Aeq,beq );
save DelColSysRel_phase1
% load DelColSysRel_phase1

%% PHASE II
[b_,B,cB,z] = PHASE2_MIN(bin,Aieq,bieq,Aeq,beq,B,@fc_ADK69_link,Cut);
save DelColSysRel_phase2
% %}
load DelColSysRel_phase2
% 
%% Add Constraints
OPTIM = z; maxSl = []; maxCount = [];
Nl = 1; % # of constraints to be added at a time
Iin_global = 1;
tmp_ = 1:length(Eb);
comp_in_ = cell2mat( Scomps([13 10 12])' );
tmp_ = find( cellfun( @(x) all(ismember(x,comp_in_)),Eb ) );


Sl = -1;
%}
% load ex1_backup
load ex1

comp_in_ = cell2mat( Scomps([6 12 13 8 10])' );
tmp_ = find( cellfun( @(x) all(ismember(x,comp_in_)),Eb ));

while ~isempty(Iin_global)

    [B,bin,Iin_global,Aieq,bieq,Aeq,beq,Sl,sign,artVar_idx,count] = ...
        ADD_CONSTRAINTS( b,Eb,B,b_,Nx,Nl,bin,Iin_idx,Aieq,bieq,tmp_,cB);
    Iin_idx = [Iin_idx(:); Iin_global(:)];
    [b_,B,cB,z] = REOPT_MIN(bin,Aieq,bieq,Aeq,beq,B,@fc_ADK69_link,Nx,sign,artVar_idx,Cut);
    OPTIM = [OPTIM; z]; 
    maxCount = [maxCount; max(abs(count))];
    maxSl = [maxSl; max(abs(Sl))];
    
    disp( [' max count: ' num2str(max(abs(count)))] )
    disp( [' Added constraint: ' num2str( Eb{Iin_global} ) ] )
    
    save ex1    
    if rem(length(OPTIM),5)==1; save ex1_backup1; end
    if rem(length(OPTIM),10)==1; save ex1_backup2; end
    if rem(length(OPTIM),20)==1; save ex1_backup3; end
end
save PowerNet_UpperBound