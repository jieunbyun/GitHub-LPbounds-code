function [b_,B,cB,z] = PHASE2_MIN(bin,Aieq,bieq,Aeq,beq,B,fc,Cut)
Nb = length(bin);
cB = fc( B,Cut );
b_ = lsqminnorm(B,bin);
btmp = ( abs(b_) <= 1e-14 );
b_(btmp) = 0;
z = cB*b_; 

% Super Comps
Scomps{1}=[1:3 10:12]; Scomps{2,1} = 4:6; Scomps{3} = [7:9 13:15]; Scomps{4} = [16:18 25:27];
Scomps{5} = 19:21; Scomps{6} = [22:24 28:30]; Scomps{7} = [31:33 37:39]; Scomps{8} = [34:36 43:45];
Scomps{9} = 40:42; Scomps{10} = 46:48; Scomps{11} = [49:51 55:57]; Scomps{12} = 52:54;
Scomps{13} = 58:59;
Ns = length(Scomps);

% Cut-sets (in terms of Scomps)
Nc = length(Cut);

Nsc = Ns+Nc;
% constraints for zero cost
Aieq2 = [Aieq zeros(size(Aieq,1),Nsc)]; bieq2 = bieq;
for ii = 1:Ns % same definition w/ failure case
    for jj = 1:length(Scomps{ii})
        a_ = zeros(1,Nb+Nsc);
        a_(Scomps{ii}(jj)) = -1;
        a_(Nb+ii) = -1;
        Aieq2 = [Aieq2;a_];
        bieq2 = [bieq2;-1];
    end
    a_ = zeros(1,Nb+Nsc);
    a_(Scomps{ii}) = 1;
    a_(Nb+ii) = 1;
    Aieq2 = [Aieq2;a_];
    bieq2 = [bieq2;length(Scomps{ii})];
end
for ii = 1:Nc
    for jj = 1:length(Cut{ii})
        a_ = zeros(1,Nb+Nsc);
        a_(Cut{ii}(jj)+Nb) = -1;
        a_(Nb+Ns+ii) = 1;
        Aieq2 = [Aieq2;a_];
        bieq2 = [bieq2;0];
    end
    a_ = zeros(1,Nb+Nsc);
    a_(Cut{ii}+Nb) = 1;
    a_(Nb+Ns+ii) = -1;
    Aieq2 = [Aieq2;a_];
    bieq2 = [bieq2;length(Cut{ii})-1];
end
a_ = zeros(1,Nb+Nsc);
a_(Nb+Ns+(1:Nc)) = -1;
Aieq2 = [Aieq2;a_];
bieq2 = [bieq2;-1];

Aeq2 = [Aeq zeros(size(Aeq,1),Nsc)];

niter = 0;
while 1    
    niter = niter+1;
    niter2 = 0;
    y_ = lsqminnorm(B',cB');
    y_( abs(y_) < 1e-12 ) = 0;

    [a_opt,c_opt] = cplexbilp( -y_,Aieq,bieq,Aeq,beq );
    c_opt = -c_opt;

    if c_opt > 1+1e-12
        ain = a_opt;
    elseif c_opt < 1e-12 || isempty( c_opt )
        break; % Optimal soln has been found.
    elseif ~fc( a_opt,Cut )
        ain = a_opt;
    else
        % for zero cost
        S = []; C = [];
        for ii = 1:size(B,1) % for each basis
            s_ = zeros(Ns,1); 
            for jj = 1:Ns
                s_(jj) = (sum(B(Scomps{jj},ii))>0)*1;
            end
            S = [S s_];
            c_ = zeros(Nc,1);
            for jj = 1:Nc
                c_(jj) = all(s_(Cut{jj}))*1;
            end
            C = [C c_];
        end            

        y_2 = [y_; zeros(Nsc,1)];
        [a_opt,c_opt] = cplexbilp( -y_2,Aieq2,bieq2,Aeq2,beq );
        c_opt = -c_opt;
        a_opt = a_opt(1:Nb);
        
        if fc( a_opt,Cut ); error('Something is wrong in 0 cost setting'); end % for debugging
        if c_opt < 0+1e-12 % c<=0
            break; % Optimal soln has been found.
        else
            ain = a_opt;
        end
    end       

    if ~isempty( b_==0 ) 
        b_(b_==0) = 1e-14*rand(sum(b_==0),1);
    end

    A_ = lsqminnorm(B,ain);
    step = b_./A_;
    posidx_ = find(step>0);
    [~,Iout] = min( step(step>0) );
    Iout = posidx_( Iout );

    B(:,Iout) = ain;
    cB(Iout) = fc(ain,Cut);
    b_ = lsqminnorm(B,bin);
    btmp = ( abs(b_) <= 1e-14 );
    b_(btmp) = 0;
    z = cB*b_;     
    
    if rem(niter,400) == 1
        disp( ['[Phase 2-MIN] ' num2str(niter) '-th iter -- Cost function: ' num2str(z)] );
        save DelColSysRel_phase2_
    end
end

disp( ['[Phase 2-MIN] Optimal value: ' num2str(z)] )
save DelColSysRel_phase2