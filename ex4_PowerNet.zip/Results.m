%{
07-11-18 
Intermediate Result
%}
clear; close all
%%
load UpperBound/PowerNet_UpperBound OPTIM
OPTIM_Up = 1-OPTIM;
load LowerBound/PowerNet_LowerBound OPTIM
Nconst = 1:200;
OPTIM_Low = OPTIM(Nconst);
load PowerNet_Duplicate/PowerNet_Super

clearvars OPTIM

%% figure
LW = 1.2; Fsz = 16; Msz = 4;

plot( Nconst,OPTIM_Low,'-b','MarkerSize',Msz,'Linewidth',LW )
hold on
plot( [Nconst(1) Nconst(end)],BndSuperBi(1)*ones(1,2),'--r','MarkerSize',Msz,'Linewidth',LW )
plot( 1:length(OPTIM_Up),OPTIM_Up,'-b','MarkerSize',Msz,'Linewidth',LW )
plot( [Nconst(1) Nconst(end)],BndSuperBi(2)*ones(1,2),'--r','MarkerSize',Msz,'Linewidth',LW )

grid on
legend({'Proposed method' 'Der Kiureghian and Song (2008)'},'Fontsize',Fsz-2,'Location','NorthEast',...
    'FontName','times new roman')

ax = gca;
ax.XAxis.FontSize = Fsz-4;
ax.YAxis.FontSize = Fsz-4;
axis([Nconst(1) Nconst(end) 0 0.1])
xlabel( 'Number of constraints','Fontsize',Fsz,'FontName','times new roman' )
ylabel( 'Failure probability','Fontsize',Fsz,'FontName','times new roman' )
saveas(gcf,'figure/PowerNet_result.emf')
saveas(gcf,'figure/PowerNet_result.pdf')