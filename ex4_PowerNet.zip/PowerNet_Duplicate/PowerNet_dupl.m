%{
2018-06-27-WED
Duplicate ADK & Song 2008
%}
clear; close all;
%%
load PowerNet
Ns = length(Scomps);
Sbnd = zeros(Ns,2);
for ii = 1:Ns

    Scomps_  = Scomps{ii};
    Nx_ = length(Scomps_);
    
    combs_ = nchoosek(1:Nx_,2);
    combs_ = mat2cell( combs_,ones(size(combs_,1),1),size(combs_,2) );
    Aeq = zeros( Nx_+size(combs_,1),2^Nx_ );
    
    c_ = 0;
    for jj = 1:Nx % the events that are not included
        combs2_ = nchoosek(1:Nx_,jj);
        for kk = 1:size(combs2_,1)
            c_ = c_+1;
            combs3_ = setdiff(1:Nx_,combs2_(kk,:));
            tmp_ = find( cellfun( @(x) isempty( intersect(combs3_,x) ),combs_ ) );
            Aeq( combs2_(kk,:),c_) = 1;
            Aeq(tmp_+Nx_,c_) = 1;            
        end        
    end
    f = (sum(Aeq)>0)*1;
    Aeq = [Aeq; ones(1,2^Nx_)];
    
    beq = P1(Scomps_);
    combs4_ = nchoosek(Scomps_,2);
    for jj = 1:size(combs4_,1)
        pidx_ = find( cellfun( @(x) ismember(combs4_(jj,:),x,'rows'),Eb ) );
        beq = [beq; P2(pidx_)];
    end
    beq = [beq;1];
        
    [~,fmin] = linprog(f,[],[],Aeq,beq,zeros(2^Nx_,1),ones(2^Nx_,1));
    [~,fmax] = linprog(-f,[],[],Aeq,beq,zeros(2^Nx_,1),ones(2^Nx_,1));
    Sbnd(ii,:) = [fmin -fmax];
end

%% Uni-comp.
Aieq2 = zeros( Ns,2^Ns );
c_ = 0;
for ii = 1:Ns
    combs_ = nchoosek(1:Ns,ii);
    for jj = 1:size(combs_,1)
        c_ = c_+1;
        Aieq2(combs_(jj,:),c_) = 1;
    end
end
f2 = zeros(size(Aieq2,2),1);
for ii = 1:length(f2)
   tmp_ = find( Aieq2(:,ii) ); 
   tmp2_ = cellfun( @(x) all(ismember(x,tmp_)),Cut );
   if sum(tmp2_)
       f2(ii) = 1;
   end
end
Aieq2 = [-Aieq2; Aieq2]; bieq2 = [-Sbnd(:,1); Sbnd(:,2)];
[~,fmin2] = linprog( f2,Aieq2,bieq2,ones(1,2^Ns),1,zeros(2^Ns,1),ones(2^Ns,1) );
[~,fmax2] = linprog( -f2,Aieq2,bieq2,ones(1,2^Ns),1,zeros(2^Ns,1),ones(2^Ns,1) );
fmax2 = -fmax2;

%% Super-Bi-Comp.
COMB = nchoosek(1:Ns,2); Sbnd2 = zeros( size(COMB,1),2 );
for ii = 1:size(COMB,1)
   comb_ = COMB(ii,:);
   S1_ = Scomps{comb_(1)}; S2_ = Scomps{comb_(2)};
   Nx1_ = length(S1_); Nx2_ = length(S2_);
   Nx_ = Nx1_ + Nx2_;
   Scomps_ = [S1_ S2_];
   
   combs_ = nchoosek(1:Nx_,2);
   combs_ = mat2cell( combs_,ones(size(combs_,1),1),size(combs_,2) );
   Aeq = zeros( Nx_ + nchoosek(Nx_,2),2^Nx_ );
   
   c_ = 0;
    for jj = 1:Nx % the events that are not included
        combs2_ = nchoosek(1:Nx_,jj);
        for kk = 1:size(combs2_,1)
            c_ = c_+1;
            combs3_ = setdiff(1:Nx_,combs2_(kk,:));
            tmp_ = find( cellfun( @(x) isempty( intersect(combs3_,x) ),combs_ ) );
            Aeq( combs2_(kk,:),c_) = 1;
            Aeq(tmp_+Nx_,c_) = 1;            
        end        
    end
    f = (sum(Aeq(1:Nx1_,:))>0).*(sum(Aeq(Nx1_+(1:Nx2_),:))>0);
    
    Aeq = [Aeq; ones(1,2^Nx_)];
    
    beq = P1(Scomps_);
    combs4_ = nchoosek(Scomps_,2);
    for jj = 1:size(combs4_,1)
        combs_tmp = sort(combs4_(jj,:));
        pidx_ = find( cellfun( @(x) ismember(combs_tmp,x,'rows'),Eb ) );
        beq = [beq; P2(pidx_)];
    end
    beq = [beq;1];
        
    [~,fmin] = linprog(f,[],[],Aeq,beq,zeros(2^Nx_,1),ones(2^Nx_,1));
    [~,fmax] = linprog(-f,[],[],Aeq,beq,zeros(2^Nx_,1),ones(2^Nx_,1));
    Sbnd2(ii,:) = [fmin -fmax];
   
end

%% System Rel. by Super-bi-Comp
Aieq3 = [];
for ii = 1:size(COMB,1)
    comb_ = COMB(ii,:);
    aieq_ = prod( Aieq2(comb_,:) );
    Aieq3 = [Aieq3; aieq_];    
end
Aieq3 = [Aieq2; -Aieq3; Aieq3];
bieq3 = [bieq2;-Sbnd2(:,1); Sbnd2(:,2)];

[~,fmin3] = linprog( f2,Aieq3,bieq3,ones(1,2^Ns),1,zeros(2^Ns,1),ones(2^Ns,1) );
[~,fmax3] = linprog( -f2,Aieq3,bieq3,ones(1,2^Ns),1,zeros(2^Ns,1),ones(2^Ns,1) );
fmax3 = -fmax3;

BndSuperUni = [fmin2 fmax2];
BndSuperBi = [fmin3 fmax3];

save PowerNet_Super BndSuperUni BndSuperBi